class OwnerValidator {
   async verifyOwner(credentialId, ownerId, entityType) {
      throw new Error('OWNER_VALIDATOR.METHOD_NOT_IMPLEMENTED');
   }
}

module.exports = OwnerValidator;
